/* stub for arch-specific syscall issues */
